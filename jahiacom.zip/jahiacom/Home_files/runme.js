!function ($) {

    $(function(){

        var $window = $(window)

        // make code pretty
        window.prettyPrint && prettyPrint()

        $('a[href^="http://"]').attr('target','_blank');
    })

}(window.jQuery)

