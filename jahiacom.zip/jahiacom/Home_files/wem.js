wem = {
    setCookie: function (cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires="+d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires;
    },

    getCookie:function (cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
        }
        return "";
    },

    registerEvent: function (event) {
        if (window.digitalData) {
            if (window.cxs) {
                console.error("already loaded, too late ..");
            } else {
                window.digitalData.events = window.digitalData.events || [];
                window.digitalData.events.push(event);
            }
        } else {
            window.digitalData = {};
            window.digitalData.events = window.digitalData.events || [];
            window.digitalData.events.push(event);
        }
    },

    registerFilterCallbacks: function (filter, callback) {
        if (window.digitalData) {
            if (window.cxs) {
                console.error("already loaded, too late ..");
            } else {
                console.log("wem: digitalData object present but not loaded, registering filter callback...");
                window.digitalData.filterCallback = window.digitalData.filterCallback || [];
                window.digitalData.filterCallback.push({filter: filter, callback: callback});
            }
        } else {
            window.digitalData = {};
            window.digitalData.filterCallback = window.digitalData.filterCallback || [];
            window.digitalData.filterCallback.push({filter: filter, callback: callback});
        }
    },

    getFilterTargets: function () {
        var targets = [];
        if (window.digitalData.filterCallback) {
            for (var i = 0; i < window.digitalData.filterCallback.length; i++) {
                var currentNodeFilters = window.digitalData.filterCallback[i].filter;
                for (var j = 0; j < currentNodeFilters.filters.length; j++) {
                    var currentNodeFilter = currentNodeFilters.filters[j];
                    for (var k = 0; k < currentNodeFilter.appliesOn.length; k++) {
                        var applyOnEntry = currentNodeFilter.appliesOn[k];
                        targets.push(applyOnEntry);
                    }
                }
            }
        }
        return targets;
    },

    registerCallbacks: function (onLoadCallback) {
        if (window.digitalData) {
            if (window.cxs) {
                console.log("wem: digitalData object loaded, calling on load callback immediately and registering update callback...");
                if (onLoadCallback) {
                    onLoadCallback(window.digitalData);
                }
            } else {
                console.log("wem: digitalData object present but not loaded, registering load callback...");
                if (onLoadCallback) {
                    window.digitalData.loadCallbacks = window.digitalData.loadCallbacks || [];
                    window.digitalData.loadCallbacks.push(onLoadCallback);
                }
            }
        } else {
            console.log("wem: No digital data object found, creating and registering update callback...");
            window.digitalData = {};
            if (onLoadCallback) {
                window.digitalData.loadCallbacks = [];
                window.digitalData.loadCallbacks.push(onLoadCallback);
            }
        }
    },

    registerPersonalization: function(filters, strategy, target, fallback, ajax) {
        var noConditionsFilters = [];
        for (var filterId in filters) {
            if (filters.hasOwnProperty(filterId)) {
                var filterWrapper = filters[filterId];
                if (filterWrapper.filter.filters.length > 0) {
                    //register filter
                    wem.registerFilterCallbacks(filterWrapper.filter, function () {
                    });
                } else {
                    //no filter assume that the content pass the test
                    noConditionsFilters.push({
                        "filterId": filterId,
                        "priority": filterWrapper.priority,
                        "content": filterWrapper.content
                    })
                }
            }
        }

        // look on filter results and define the content to display base on the strategy
        wem.registerCallbacks(function () {
            var successfulFilters = [];
            for (var filterId in cxs.filteringResults) {
                if (cxs.filteringResults.hasOwnProperty(filterId)) {
                    if (filters.hasOwnProperty(filterId)) {
                        if (cxs.filteringResults[filterId]) {
                            successfulFilters.push({
                                "filterId": filterId,
                                "priority": filters[filterId].priority,
                                "content": filters[filterId].content
                            })
                        }
                    }
                }
            }
            var selectedFilter;

            function compareFn(a, b) {
                // sort in reverse order of priority so that the first element is the highest priority one
                return -(a.priority - b.priority);
            }

            function randomIndex(array) {
                return Math.floor(Math.random() * array.length);
            }

            if (strategy == 'matching-first') {
                // if a filter matches, it should be selected before any no-condition ones
                // if we have successful filters, find the one with the highest priority
                if (successfulFilters.length > 0) {
                    successfulFilters.sort(compareFn);
                    selectedFilter = successfulFilters[0];
                } else {
                    // we didn't have an explicit filter match, look at the no conditions ones
                    noConditionsFilters.sort(compareFn);
                    selectedFilter = noConditionsFilters[0];
                }
            } else {
                successfulFilters = successfulFilters.concat(noConditionsFilters);
                if (strategy == "priority") {
                    successfulFilters.sort(compareFn);
                    selectedFilter = successfulFilters[0];
                } else if (strategy == "random") {
                    selectedFilter = successfulFilters[randomIndex(successfulFilters)];
                }
            }


            if(!selectedFilter && fallback && filters[fallback]) {
                selectedFilter = {
                    "filterId": fallback,
                    "priority": filters[fallback].priority,
                    "content": filters[fallback].content
                }
            }

            if (selectedFilter) {
                if (ajax) {
                    $('#' + target).load(selectedFilter.content);
                } else {
                    var selectedContent = $('#' + selectedFilter.content);
                    selectedContent.siblings().hide();
                    selectedContent.show();
                }
            } else {
                if (ajax) {
                    $('#' + target).html("");
                } else {
                    $('#' + target + " > div").hide();
                }
            }
        });
    },

    registerOptimizationTest: function (optimizationTestNodeId, goalId, containerId, variants, ajax) {
        var selectedVariantId = sessionStorage.getItem(optimizationTestNodeId);
        if (!(selectedVariantId && variants[selectedVariantId])) {
            var keys = Object.keys(variants);
            selectedVariantId = keys[keys.length * Math.random() << 0];
            sessionStorage.setItem(optimizationTestNodeId, selectedVariantId);
            wem.registerEvent({
                eventType: "optimizationTestEvent",
                scope: window.digitalData.scope,
                source: {
                    itemType: "page",
                    scope: window.digitalData.scope,
                    itemId: window.digitalData.page.pageInfo.pageID,
                    properties: window.digitalData.page
                },
                target: {
                    itemType: "optimizationTest",
                    scope: window.digitalData.scope,
                    itemId: optimizationTestNodeId,
                    properties: {
                        variantId: selectedVariantId,
                        goalId: goalId
                    }
                }
            });
        }

        if (selectedVariantId) {
            if (ajax) {
                $("#" + containerId).load(variants[selectedVariantId].content);
            } else {
                $('#' + variants[selectedVariantId].content).show()
            }
        }
    },

    extractFormData: function (form) {
        var params = {};
        for (var i=0; i < form.elements.length; i++) {
            var e = form.elements[i];
            if (typeof(e.name) != 'undefined') {
                switch (e.nodeName) {
                    case 'TEXTAREA':
                    case "INPUT":
                        switch (e.type) {
                            case 'checkbox':
                            case 'radio':
                                if (e.checked) {
                                    params[e.name] = e.value;
                                }
                                break;
                            default:
                                if (!e.value || e.value == "") {
                                    // ignore element if no value is provided
                                    break;
                                }
                                params[e.name] = e.value;
                        }
                        break;
                    case "SELECT":
                        if (e.options && e.options[e.selectedIndex]) {
                            params[e.name] = e.options[e.selectedIndex].value;
                        }
                        break;
                }
            }
        }
        return params;
    },

    init: function(contextServerPublicUrl, sessionID, isPreview) {
        var instance = this;
        this.contextServerPublicUrl = contextServerPublicUrl;
        this.sessionID = sessionID;

        if(isPreview) {
            return;
        }
        if (!navigator.cookieEnabled) {
            return;
        }

        wem.registerEvent({
            eventType:"view",
            scope: window.digitalData.scope,
            source:{
                itemType: "site",
                scope: window.digitalData.scope,
                itemId: window.digitalData.site.siteInfo.siteID
            },
            target:{
                itemType: "page",
                scope: window.digitalData.scope,
                itemId: window.digitalData.page.pageInfo.pageID,
                properties: window.digitalData.page
            }
        });

        document.addEventListener('DOMContentLoaded',function () {
            jsonData = {
                source:{
                    itemType: "page",
                    scope: window.digitalData.scope,
                    itemId: window.digitalData.page.pageInfo.pageID,
                    properties:window.digitalData.page
                },
                events:window.digitalData.events
            };
            if (window.digitalData.filterCallback) {
                jsonData.filters = window.digitalData.filterCallback.map(function(x) {return x.filter})
            }
            data = JSON.stringify(jsonData);

            var personaId = wem.getCookie("context-persona-id");
            var url = contextServerPublicUrl + '/context.js?sessionId=' +sessionID;
            if (personaId) {
                return;
            }


            var xhr = new XMLHttpRequest();
            if ("withCredentials" in xhr) {
                xhr.open("POST", url, true);
                xhr.withCredentials = true;
            } else if (typeof XDomainRequest != "undefined") {
                xhr = new XDomainRequest();
                xhr.open("POST", url);
            }
            xhr.onreadystatechange = function() {
                if ( xhr.readyState == 4 ) {
                    if ( xhr.status == 200 || xhr.status == 304 ) {
                        if ( ( xhr.responseText != null ) && ( !document.getElementById( "contextjs" ) ) ){
                            var oHead = document.getElementsByTagName('HEAD').item(0);
                            var oScript = document.createElement( "script" );
                            oScript.language = "javascript";
                            oScript.type = "text/javascript";
                            oScript.id = "contextjs";
                            oScript.defer = true;
                            oScript.text = xhr.responseText;
                            oHead.appendChild( oScript );
                        }
                    } else {
                        console.error( 'XML request error: ' + xhr.statusText + ' (' + xhr.status + ')' ) ;
                    }
                }
            };
            xhr.setRequestHeader("Content-Type", "text/plain;charset=UTF-8"); // Use text/plain to avoid CORS preflight
            xhr.send(data);
            console.log("wem: context loading...");
        });

        // Capture all submit at document level
        wem.registerCallbacks(function() {
            // process tracked events
            var formNamesToWatch = [];
            var videoNamesToWatch = [];
            if(cxs.trackedConditions && cxs.trackedConditions.length > 0){
                for (var i = 0; i < cxs.trackedConditions.length; i++) {
                    switch (cxs.trackedConditions[i].type) {
                        case "formEventCondition":
                            if(cxs.trackedConditions[i].parameterValues && cxs.trackedConditions[i].parameterValues.formId){
                                formNamesToWatch.push(cxs.trackedConditions[i].parameterValues.formId)
                            }
                            break;
                        case "videoViewEventCondition":
                            if(cxs.trackedConditions[i].parameterValues && cxs.trackedConditions[i].parameterValues.videoId){
                                videoNamesToWatch.push(cxs.trackedConditions[i].parameterValues.videoId)
                            }
                            break;
                    }
                }
            }

            // register form events
            var f = function (event) {
                var form = event.target;
                var formName = form.name ? form.name : form.id;
                if (formName && formNamesToWatch.indexOf(formName) > -1) {
                    console.log("wem: catching form "+form.name);

                    var eventCopy = document.createEvent('Event');
                    // Define that the event name is 'build'.
                    eventCopy.initEvent('submit', event.bubbles, event.cancelable);

                    event.stopImmediatePropagation();
                    event.preventDefault();

                    var formEvent = {
                        scope: window.digitalData.scope,
                        eventType: "form",
                        source:{
                            itemType: "page",
                            scope: window.digitalData.scope,
                            itemId: window.digitalData.page.pageInfo.pageID,
                            properties: window.digitalData.page
                        },
                        target: {
                            itemType:"form",
                            scope: window.digitalData.scope,
                            itemId:formName
                        },
                        properties: {}
                    };
                    // merge form properties with event properties
                    var formData =  wem.extractFormData(form);
                    for(var formInput in formData) formEvent.properties[formInput]=formData[formInput];


                    cxs.collectEvent(formEvent,
                        function () {
                            console.log("wem: Form event successfully submitted.");
                            document.body.removeEventListener('submit', f, true);
                            form.dispatchEvent(eventCopy);
                            if (!eventCopy.defaultPrevented && !eventCopy.cancelBubble) {
                                form.submit();
                            }
                        },
                        function (xhr) {
                            console.log("wem: Error while collecting form event: " + xhr.status + " " + xhr.statusText);
                            xhr.abort();
                            form.dispatchEvent(eventCopy);
                            if (!eventCopy.defaultPrevented && !eventCopy.cancelBubble) {
                                form.submit();
                            }
                        }
                    );
                }
            };
            document.body.addEventListener('submit', f, true);
            console.log("wem: watching forms");

            // register video events
            sendVideoEvent = function(event){
                console.log("wem: catching video event");
                var videoId = event.target.id;
                var videoEvent = {
                    scope: window.digitalData.scope,
                    eventType: "video",
                    source:{
                        itemType: "page",
                        scope: window.digitalData.scope,
                        itemId: window.digitalData.page.pageInfo.pageID,
                        properties: window.digitalData.page
                    },
                    target: {
                        itemType:"video",
                        scope: window.digitalData.scope,
                        itemId:videoId
                    },
                    properties: {
                        "event":event.type
                    }
                };

                cxs.collectEvent(videoEvent,
                    function () {
                        console.log("wem: Video event successfully collected.");
                    }
                );
            };

            for (var j = 0; j < videoNamesToWatch.length; j++) {
                var videoName = videoNamesToWatch[j];
                var video = $("#" + videoName);
                if(video){
                    video.on('play',sendVideoEvent);
                    video.on('ended',sendVideoEvent);
                    console.log("wem: watching video "+videoName);
                } else {
                    console.log("wem: unable to watch video " + videoName + ", video not found in the page");
                }
            }
        });

    },

    loadPersonaContext: function (personaId, segmentOverrides, profilePropertiesOverrides, sessionPropertiesOverrides) {
        var url = this.contextServerPublicUrl + '/context.js?sessionId=' + this.sessionID + "&personaId=" + personaId;

        wem.setCookie("context-persona-id", personaId, 1);

        var xhr = new XMLHttpRequest();
        if ("withCredentials" in xhr) {
            xhr.open("POST", url, true);
            xhr.withCredentials = true;
        } else if (typeof XDomainRequest != "undefined") {
            xhr = new XDomainRequest();
            xhr.open("POST", url);
        }
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200 || xhr.status == 304) {
                    if (xhr.responseText != null) {
                        if (!document.getElementById("contextjs")) {
                            var oHead = document.getElementsByTagName('HEAD').item(0);
                            var oScript = document.createElement("script");
                            oScript.language = "javascript";
                            oScript.type = "text/javascript";
                            oScript.id = "contextjs";
                            oScript.defer = true;
                            oScript.text = xhr.responseText;
                            oHead.appendChild(oScript);
                        } else {
                            var existingScript = document.getElementById("contextjs");
                            existingScript.parentNode.removeChild(existingScript);
                            var oHead = document.getElementsByTagName('HEAD').item(0);
                            var oScript = document.createElement("script");
                            oScript.language = "javascript";
                            oScript.type = "text/javascript";
                            oScript.id = "contextjs";
                            oScript.defer = true;
                            oScript.text = xhr.responseText;
                            oHead.appendChild(oScript);
                        }
                    }
                } else {
                    console.error('XML request error: ' + xhr.statusText + ' (' + xhr.status + ')');
                }
            }
        };
        xhr.setRequestHeader("Content-Type", "text/plain;charset=UTF-8"); // Use text/plain to avoid CORS preflight
        jsonData = {
            source: {
                itemType: "page",
                scope: window.digitalData.scope,
                itemId: window.digitalData.page.pageInfo.pageID,
                properties: window.digitalData.page
            },
            requireSegments: true,
            requiredProfileProperties: ['*'],
            requiredSessionProperties: ['*'],
            events: window.digitalData.events,
            segmentOverrides: segmentOverrides,
            profilePropertiesOverrides: profilePropertiesOverrides,
            sessionPropertiesOverrides: sessionPropertiesOverrides
        };
        if (window.digitalData.filterCallback) {
            jsonData.filters = window.digitalData.filterCallback.map(function(x) {return x.filter})
        }
        data = JSON.stringify(jsonData);
        xhr.send(data);
        console.log("wem: persona context loading...");
    }
};


